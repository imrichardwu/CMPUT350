CMPUT 350  Assignment 3
-----------------------

Student Id:
            ----------------


I hereby acknowledge the following sources that helped me finish this
assignment (fellow students, TAs, books, internet, ...) and how they
contributed:










Your name in lieu of a signature:



           -----------------------
